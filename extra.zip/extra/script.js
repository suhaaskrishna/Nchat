function sendMessage() {
  var inputElement = document.getElementById('message-input');
  var message = inputElement.value;

  if (message.trim() !== '') {
    var chatMessages = document.getElementById('chat-messages');
    var newMessage = document.createElement('div');
    newMessage.className = 'message user-message';
    newMessage.textContent = message;
    chatMessages.appendChild(newMessage);

    // Clear the input field after sending the message
    inputElement.value = '';

    // Scroll to the bottom of the chat messages
    chatMessages.scrollTop = chatMessages.scrollHeight;
  }
}
